//
//  WBImageSegue.h
//  SmartReceipts
//
//  Created on 10/04/14.
//  Copyright (c) 2014 Will Baumann. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WBImageSegue : UIStoryboardSegue

@end
