//
//  WBNoTripsViewController.h
//  SmartReceipts
//
//  Created on 23/04/14.
//  Copyright (c) 2014 Will Baumann. All rights reserved.
//

#import "WBViewController.h"

@interface WBNoTripsViewController : WBViewController
@property (weak, nonatomic) IBOutlet UILabel *labelNoReportSelected;

@end
