//
//  WBNewReceiptViewController.m
//  SmartReceipts
//
//  Created on 14/03/14.
//  Copyright (c) 2014 Will Baumann. All rights reserved.
//

#import "WBNewReceiptViewController.h"

#import "WBReceiptsViewController.h"

#import "WBTextUtils.h"
#import "WBDateFormatter.h"

#import "WBReceipt.h"
#import "WBCurrency.h"

#import "WBDB.h"
#import "WBPreferences.h"
#import "WBFileManager.h"

#import "WBAutocompleteHelper.h"

static const int TAG_CURRENCY = 1, TAG_CATEGORY = 2;

@interface WBNewReceiptViewController () {
    WBDynamicPicker* _dynamicPicker;
    WBDynamicPicker* _dynamicDatePicker;
    
    WBDateFormatter* _dateFormatter;
    
    WBTrip *_trip;
    WBReceipt *_receipt;
    
    UIImage *_image;
    
    NSString *_name;
    NSString *_price;
    long long _dateMs;
    NSString *_comment;
    BOOL _isExpensable;
    BOOL _isFullPage;
    
    NSTimeZone *_timeZone;
    
    NSArray *_categoriesNames;
    NSArray *_currenciesCodes;
    
    WBAutocompleteHelper *_autocompleteHelper;
    
    NSUserDefaults *prefs;
}

@end

@implementation WBNewReceiptViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    prefs = [NSUserDefaults standardUserDefaults];
    
    NSObject * object = [prefs objectForKey:@"price"];
    if(object != nil){
        //object is there
        [prefs removeObjectForKey:@"price"];
        [prefs synchronize];
    }
    
    NSObject * object1 = [prefs objectForKey:@"tax"];
    if(object1 != nil){
        //object is there
        [prefs removeObjectForKey:@"tax"];
        [prefs synchronize];
    }
    
    self.labelName.text = NSLocalizedString(@"Name", nil);
    self.labelPrice.text = NSLocalizedString(@"Price", nil);
    self.labelTax.text = NSLocalizedString(@"Tax", nil);
    
    self.labelCurrency.text = NSLocalizedString(@"Currency", nil);
    self.labelDate.text = NSLocalizedString(@"Date", nil);
    self.labelCategory.text = NSLocalizedString(@"Category", nil);
    
    self.labelComment.text = NSLocalizedString(@"Comment", nil);
    self.labelExpensable.text = NSLocalizedString(@"Expensable", nil);
    self.labelFullPageImage.text = NSLocalizedString(@"Full Page Image", nil);
    
    self.nameTextField.placeholder = NSLocalizedString(@"Name of your receipt", nil);
    self.priceTextField.placeholder = NSLocalizedString(@"e.g. 25.00", nil);
    self.taxTextField.placeholder = NSLocalizedString(@"e.g. 5.00", nil);
    self.commentField.placeholder = NSLocalizedString(@"Your comments here", nil);
    
    _categoriesNames = [[WBDB categories] categoriesNames];
    _currenciesCodes = [WBCurrency allCurrencyCodes];
    
    _dateFormatter = [[WBDateFormatter alloc] init];
    
    _dynamicPicker = [[WBDynamicPicker alloc] initWithType:WBDynamicPickerTypePicker withController:self];
    _dynamicPicker.delegate = self;
    
    _dynamicDatePicker = [[WBDynamicPicker alloc] initWithType:WBDynamicPickerTypeDate withController:self];
    _dynamicDatePicker.delegate = self;
    
    _autocompleteHelper = [[WBAutocompleteHelper alloc] initWithAutocompleteField:self.nameTextField inView:self.view useReceiptsHints:YES];
    
    self.priceTextField.delegate = self;
    self.taxTextField.delegate = self;
    self.nameTextField.delegate = self;
    
    [self.nameTextField becomeFirstResponder];
    
    NSString *currencyCode = nil;
    NSString *category = nil;
    
    if (_receipt) {
        self.navigationItem.title = NSLocalizedString(@"Edit Receipt", nil);
        self.nameTextField.text = [_receipt name];
        
        NSString *newStrPrice = [_receipt price_as_string];
        NSString *strPrice = [self formattedMoneyString:newStrPrice curr:[[_receipt currency] code]];
        
        currencyCode = [[_receipt currency] code];
        //NSString *currencyCode = self.currencyButton.titleLabel.text;
       // NSLocale *locale = [[NSLocale alloc] initWithLocaleIdentifier:currencyCode];
       // NSString *currencySymbol = [NSString stringWithFormat:@"%@",[locale displayNameForKey:NSLocaleCurrencySymbol value:currencyCode]];
       // NSLog(@"Currency Symbol : %@", currencySymbol);
        
        //float textfieldvalue = (CGFloat)[strPrice floatValue];
        //NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
        //[numberFormatter setLocale:[NSLocale currentLocale]];
        //[numberFormatter setNumberStyle: NSNumberFormatterCurrencyStyle];
        //NSString *numberAsString = [numberFormatter stringFromNumber:[NSNumber numberWithFloat:textfieldvalue]];
       // NSString *numberAsString = [NSString stringWithFormat:@"%@%@", currencySymbol, strPrice];
        self.priceTextField.text = strPrice;
        
        NSString *newStrTax = [_receipt tax_as_string];
        NSString *strTax = [self formattedMoneyString:newStrTax curr:currencyCode];
        
        //float textfieldvalue1 = (CGFloat)[strTax floatValue];
        //NSNumberFormatter *numberFormatter1 = [[NSNumberFormatter alloc] init];
       // [numberFormatter1 setLocale:[NSLocale currentLocale]];
       // [numberFormatter1 setNumberStyle: NSNumberFormatterCurrencyStyle];
       // NSString *numberAsString1 = [numberFormatter stringFromNumber:[NSNumber numberWithFloat:textfieldvalue1]];
       // NSString *numberAsString1 = [NSString stringWithFormat:@"%@%@", currencySymbol, strTax];
        self.taxTextField.text = strTax;
        
        currencyCode = [[_receipt currency] code];
        _dateMs = [_receipt dateMs];
        category = [_receipt category];
        self.commentField.text = [_receipt comment];
        self.expensableSwitch.on = [_receipt isExpensable];
        self.fullPageImageSwitch.on = [_receipt isFullPage];
        
        _timeZone = [_receipt timeZone];
    } else {
        self.navigationItem.title = NSLocalizedString(@"New Receipt", nil);
        
        currencyCode = [WBPreferences defaultCurrency];
        
        if ([WBPreferences defaultToFirstReportDate]) {
            _dateMs = [[_trip startDate] timeIntervalSince1970] * 1000;
        } else {
            _dateMs = [[NSDate date] timeIntervalSince1970] * 1000;
        }
        
        category = [self proposedCategory];
        
        _timeZone = [NSTimeZone localTimeZone];
    }
    
    if (!_receipt) {
        if ([WBPreferences matchNameToCategory]) {
            self.nameTextField.text = category;
        }
        if ([WBPreferences matchCommentToCategory]) {
            self.commentField.text = category;
        }
    }
    
    [self.currencyButton setTitle:currencyCode forState:UIControlStateNormal];
    [self.categoryButton setTitle:category forState:UIControlStateNormal];
    
    [self.dateButton setTitle:[_dateFormatter formattedDateMs:_dateMs inTimeZone:_timeZone] forState:UIControlStateNormal];
}

-(NSString*)formattedMoneyString:(NSString*) moneyString curr:(NSString *)currCode
{
    NSNumberFormatter *_currencyFormatter = [[NSNumberFormatter alloc] init];
    [_currencyFormatter setNumberStyle:NSNumberFormatterCurrencyStyle];
    [_currencyFormatter setCurrencyCode:currCode];
    return [_currencyFormatter stringFromNumber:[NSNumber numberWithDouble:[moneyString doubleValue]]];
}

- (void) checkCategoryMatches
{
    if ([WBPreferences matchNameToCategory])
    {
        self.nameTextField.text = [self.categoryButton titleForState:UIControlStateNormal];
    }
    if ([WBPreferences matchCommentToCategory])
    {
        self.commentField.text = [self.categoryButton titleForState:UIControlStateNormal];
    }
}

- (NSInteger) numberOfHiddenCells
{
    return ![WBPreferences includeTaxField];
}

- (NSInteger) numberOfHiddenCellsAbove:(NSInteger) row
{
    // Calculate how many cells are hidden above the given indexPath.row
    if ([WBPreferences includeTaxField])
    {
        return 0;
    }
    else
    {
        if (row >= 2)
        { //Tax row
            return 1;
        }
        else
        {
            return 0;
        }
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [super tableView:tableView numberOfRowsInSection:section] - [self numberOfHiddenCells];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Recalculate indexPath based on hidden cells
    indexPath = [self offsetIndexPath:indexPath];
    
    return [super tableView:tableView cellForRowAtIndexPath:indexPath];
}

- (NSIndexPath*)offsetIndexPath:(NSIndexPath*)indexPath
{
    int offsetSection = indexPath.section; // Also offset section if you intend to hide whole sections
    int offsetRow = indexPath.row + [self numberOfHiddenCellsAbove:indexPath.row];
    
    return [NSIndexPath indexPathForRow:offsetRow inSection:offsetSection];
}

/*
 - (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
 // we hide 3rd (tax)
 if (indexPath.row == 2 && ![WBPreferences includeTaxField]) {
 return 0;
 }
 else {
 return [super tableView:tableView heightForRowAtIndexPath:indexPath];
 }
 }
 */

- (NSString*) proposedCategory
{
    NSDate *now = [NSDate date];
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDateComponents *components = [calendar components:NSHourCalendarUnit fromDate:now];
    NSInteger hour = [components hour];
    
    if ([WBPreferences predictCategories])
    {
        if (hour >= 4 && hour < 11)
        {
            return [WBCategory CATEGORY_NAME_BREAKFAST];
        } else if(hour >= 11 && hour < 16){
            return [WBCategory CATEGORY_NAME_LUNCH];
        } else if(hour >= 16 && hour < 23){
            return [WBCategory CATEGORY_NAME_DINNER];
        }
    }
    return _categoriesNames.count > 0 ? [_categoriesNames objectAtIndex:0] : @"";
}

- (void)setReceipt:(WBReceipt *)receipt withTrip:(WBTrip*) trip
{
    _receipt = receipt;
    _trip = trip;
}

- (void)setReceiptImage:(UIImage *)image
{
    _image = image;
}

-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    if (textField == _priceTextField)
    {
        
        //NSData *_data = [[NSUserDefaults standardUserDefaults] objectForKey:@"price"];
        //NSString *_dataArchive = [NSKeyedUnarchiver unarchiveObjectWithData:_data];
        
        NSObject * object = [prefs objectForKey:@"price"];
        if(object != nil){
            //object is there
            textField.text = [prefs objectForKey:@"price"];
        }
        else{
            if([textField.text length]!=0){
                textField.text = [textField.text stringByReplacingOccurrencesOfString:@"[^0-9,.]" withString:@"" options:NSRegularExpressionSearch range:NSMakeRange(0, [textField.text length])];
                NSRange range = [textField.text rangeOfString:@"."];
                textField.text = [textField.text substringToIndex:range.location];
            }
        }
    }
    if ( textField == _taxTextField)
    {
        
        //NSData *_data = [[NSUserDefaults standardUserDefaults] objectForKey:@"tax"];
        //NSString *_dataArchive = [NSKeyedUnarchiver unarchiveObjectWithData:_data];
        
        NSObject * object = [prefs objectForKey:@"tax"];
        if(object != nil){
            //object is there
            textField.text = [prefs objectForKey:@"tax"];
        }
        else{
            if([textField.text length]!=0){
                textField.text = [textField.text stringByReplacingOccurrencesOfString:@"[^0-9,.]" withString:@"" options:NSRegularExpressionSearch range:NSMakeRange(0, [textField.text length])];
                NSRange range = [textField.text rangeOfString:@"."];
                textField.text = [textField.text substringToIndex:range.location];
            }
        }
    }
    
    [_autocompleteHelper textFieldDidBeginEditing:textField];
}

- (BOOL)textFieldShouldEndEditing:(UITextField *)textField
{
    return YES;
}

-(void)textFieldDidEndEditing:(UITextField *)textField
{
    NSString *currencyCode = self.currencyButton.titleLabel.text;
   // NSLocale *locale = [[NSLocale alloc] initWithLocaleIdentifier:currencyCode];
   // NSString *currencySymbol = [NSString stringWithFormat:@"%@",[locale displayNameForKey:NSLocaleCurrencySymbol value:currencyCode]];
   // NSLog(@"Currency Symbol : %@", currencySymbol);
    
    if (textField == _priceTextField )
    {
        NSLog(@"****************AAGEA");
        _str1 = textField.text;
        NSString *newStr = [_str1 stringByReplacingOccurrencesOfString:@"[^0-9,.]" withString:@"" options:NSRegularExpressionSearch range:NSMakeRange(0, [_str1 length])];
        
        // create a mutable copy, and mutate it
        NSMutableString *mutStr1 = [newStr mutableCopy];
        
        NSObject * object = [prefs objectForKey:@"price"];
        if(object != nil){
            //object is there
            [prefs removeObjectForKey:@"price"];
            [prefs setObject:mutStr1 forKey:@"price"];
            [prefs synchronize];
        }
        else{
            [prefs setObject:mutStr1 forKey:@"price"];
            [prefs synchronize];
        }
        
        //float textfieldvalue = (CGFloat)[mutStr1 floatValue];
       // NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
        //        NSLocale *locale=[[NSLocale alloc]initWithLocaleIdentifier:@"en_GB"];
       // [numberFormatter setLocale:[NSLocale currentLocale]];
       // [numberFormatter setNumberStyle: NSNumberFormatterCurrencyStyle];
        //NSString *numberAsString = [numberFormatter stringFromNumber:[NSNumber numberWithFloat:textfieldvalue]];
        
       // NSString *numberAsString = [NSString stringWithFormat:@"%@%@", currencySymbol, mutStr1];
        //NSRange range = [numberAsString rangeOfString:@"."];
        //NSString *newString = [numberAsString substringToIndex:range.location];
        //NSString *newString1 = [NSString stringWithFormat:@"%@.00",newString];
        //NSLog(@"%@",newString1);
        NSString *newString1 = [self formattedMoneyString:mutStr1 curr:currencyCode];
        textField.text = newString1;
    }
    if ( textField == _taxTextField)
    {
        _str2 = textField.text;
        NSString *newStr = [_str2 stringByReplacingOccurrencesOfString:@"[^0-9,.]" withString:@"" options:NSRegularExpressionSearch range:NSMakeRange(0, [_str2 length])];
        
        // create a mutable copy, and mutate it
        NSMutableString *mutStr2 = [newStr mutableCopy];
        
        NSObject * object = [prefs objectForKey:@"tax"];
        if(object != nil){
            //object is there
            [prefs removeObjectForKey:@"tax"];
            [prefs setObject:mutStr2 forKey:@"tax"];
            [prefs synchronize];
        }
        else{
            [prefs setObject:mutStr2 forKey:@"tax"];
            [prefs synchronize];
        }
        
        //float textfieldvalue = (CGFloat)[mutStr2 floatValue];
       // NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
        //        NSLocale *locale=[[NSLocale alloc]initWithLocaleIdentifier:@"en_GB"];
       // [numberFormatter setLocale:[NSLocale currentLocale]];
       // [numberFormatter setNumberStyle: NSNumberFormatterCurrencyStyle];
       // NSString *numberAsString = [numberFormatter stringFromNumber:[NSNumber numberWithFloat:textfieldvalue]];
       // NSString *numberAsString = [NSString stringWithFormat:@"%@%@", currencySymbol, mutStr2];
        //NSRange range = [numberAsString rangeOfString:@"="];
        //NSString *newString = [numberAsString substringToIndex:range.location];
        //NSString *newString1 = [NSString stringWithFormat:@"%@.00",newString];
        //NSLog(@"%@",newString1);
        NSString *newString1 = [self formattedMoneyString:mutStr2 curr:currencyCode];
        textField.text = newString1;
    }
    [_autocompleteHelper textFieldDidEndEditing:textField];
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    /*
    NSString *newText = [textField.text stringByReplacingCharactersInRange:range withString:string];
    
    NSLog(@"TEXTFIELD>%@",textField.text);
    
    if (self.priceTextField == textField || self.taxTextField == textField)
    {
        return [WBTextUtils isMoney:newText];
    }
     */
    // receipt name is not filtered
    //else {
    //    return [WBTextUtils isProperName:newText];
    //}
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    // Any additional checks to ensure you have the correct textField here.
    [textField resignFirstResponder];
    return YES;
}


-(NSString*) dynamicPicker:(WBDynamicPicker*) picker titleForRow:(NSInteger) row
{
    if (picker.tag == TAG_CURRENCY)
    {
        return [_currenciesCodes objectAtIndex:row];
    } else {
        return [_categoriesNames objectAtIndex:row];
    }
}

-(NSInteger) dynamicPickerNumberOfRows:(WBDynamicPicker*) picker
{
    if (picker.tag == TAG_CURRENCY) {
        return _currenciesCodes.count;
    } else {
        return _categoriesNames.count;
    }
}

-(void)dynamicPicker:(WBDynamicPicker *)picker doneWith:(id)subject
{
    if (picker == _dynamicPicker)
    {
        if (picker.tag == TAG_CATEGORY)
        {
            [self.categoryButton setTitle:[_categoriesNames objectAtIndex:[picker selectedRow]]
                                 forState:UIControlStateNormal];
            
            [self checkCategoryMatches];
        }
        else
        {
           // [self.currencyButton setTitle:[_currenciesCodes objectAtIndex:[picker selectedRow]]
                            //     forState:UIControlStateNormal];
            //self.currencyButton.titleLabel.text = [_currenciesCodes objectAtIndex:[picker selectedRow]];
            [self.currencyButton setTitle:[_currenciesCodes objectAtIndex:[picker selectedRow]]
                                 forState:UIControlStateNormal];
            [_dynamicPicker showFromView:self.currencyButton];
            
            NSString *currencyCode = [_currenciesCodes objectAtIndex:[picker selectedRow]];
            //NSLocale *locale = [[NSLocale alloc] initWithLocaleIdentifier:currencyCode];
            //NSString *currencySymbol = [NSString stringWithFormat:@"%@",[locale displayNameForKey:NSLocaleCurrencySymbol value:currencyCode]];
           // NSLog(@"Currency Symbol : %@", currencySymbol);
            
            NSString *pricee = [(UITextField *)[self.view viewWithTag:2] text];
            pricee = [pricee stringByReplacingOccurrencesOfString:@"[^0-9,.]" withString:@"" options:NSRegularExpressionSearch range:NSMakeRange(0, [pricee length])];
            pricee = [pricee stringByReplacingOccurrencesOfString:@"," withString:@""];
            //float textfieldvalue = (CGFloat)[pricee floatValue];
            //NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
            //        NSLocale *locale=[[NSLocale alloc]initWithLocaleIdentifier:@"en_GB"];
            //[numberFormatter setLocale:locale];
            //[numberFormatter setNumberStyle: NSNumberFormatterCurrencyStyle];
            //NSString *numberAsString = [numberFormatter stringFromNumber:[NSNumber numberWithFloat:textfieldvalue]];
            NSString *numberAsString = [self formattedMoneyString:pricee curr:currencyCode];//[NSString stringWithFormat:@"%@%@", currencySymbol, pricee];
            [(UITextField *)[self.view viewWithTag:2] setText:numberAsString];
            
            NSString *taxx = [(UITextField *)[self.view viewWithTag:3] text];
            taxx = [taxx stringByReplacingOccurrencesOfString:@"[^0-9,.]" withString:@"" options:NSRegularExpressionSearch range:NSMakeRange(0, [taxx length])];
            taxx = [taxx stringByReplacingOccurrencesOfString:@"," withString:@""];
            //float textfieldvalue1 = (CGFloat)[taxx floatValue];
            //NSNumberFormatter *numberFormatter1 = [[NSNumberFormatter alloc] init];
            //        NSLocale *locale=[[NSLocale alloc]initWithLocaleIdentifier:@"en_GB"];
            //[numberFormatter1 setLocale:locale];
            //[numberFormatter1 setNumberStyle: NSNumberFormatterCurrencyStyle];
            //NSString *numberAsString1 = [numberFormatter stringFromNumber:[NSNumber numberWithFloat:textfieldvalue1]];
            NSString *numberAsString1 = [self formattedMoneyString:taxx curr:currencyCode];//[NSString stringWithFormat:@"%@%@", currencySymbol, taxx];
            [(UITextField *)[self.view viewWithTag:3] setText:numberAsString1];
        }
    }
    else
    {
        _dateMs = [[picker selectedDate] timeIntervalSince1970] * 1000;
        [self.dateButton setTitle:[_dateFormatter formattedDate:[picker selectedDate] inTimeZone:_timeZone] forState:UIControlStateNormal];
    }
}

- (IBAction)currencyButtonClicked:(id)sender
{
    
    _dynamicPicker.tag = TAG_CURRENCY;
    [_dynamicPicker setTitle:NSLocalizedString(@"Currencies",nil)];
    [_dynamicPicker showFromView:self.currencyButton];
    NSUInteger currIdx = [_currenciesCodes indexOfObject:[self.currencyButton.titleLabel text]];
    [_dynamicPicker setSelectedRow:(currIdx==NSNotFound?0:currIdx)];
    
}

- (IBAction)categoryButtonClicked:(id)sender
{
    _dynamicPicker.tag = TAG_CATEGORY;
    [_dynamicPicker setTitle:NSLocalizedString(@"Categories",nil)];
    [_dynamicPicker showFromView:self.categoryButton];
    
    NSUInteger catIdx = [_categoriesNames indexOfObject:[self.categoryButton.titleLabel text]];
    if (_categoriesNames.count>0) {
        [_dynamicPicker setSelectedRow:(catIdx==NSNotFound?0:catIdx)];
    }
}

- (IBAction)dateButtonClicked:(id)sender
{
    [_dynamicDatePicker setDate:[NSDate dateWithTimeIntervalSince1970:(_dateMs/1000)]];
    [_dynamicDatePicker showFromView:self.dateButton];
}

- (IBAction)actionDone:(id)sender
{
    
    WBReceipt* newReceipt;
    
    NSString *priceVal = _priceTextField.text;
    NSString *newPrice;
    newPrice = [priceVal stringByReplacingOccurrencesOfString:@"[^0-9,.]" withString:@"" options:NSRegularExpressionSearch range:NSMakeRange(0, [priceVal length])];
    newPrice = [newPrice stringByReplacingOccurrencesOfString:@"," withString:@""];
    NSString *price =  newPrice;//[[NSUserDefaults standardUserDefaults] objectForKey:@"price"];
    
    // create a mutable copy, and mutate it
    NSMutableString *mutPrice = [price mutableCopy];
    
    [[NSUserDefaults standardUserDefaults] setObject:mutPrice forKey:@"price"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    NSString *priceTax = _taxTextField.text;
    NSString *newTax;
    newTax = [priceTax stringByReplacingOccurrencesOfString:@"[^0-9,.]" withString:@"" options:NSRegularExpressionSearch range:NSMakeRange(0, [priceTax length])];
    newTax = [newTax stringByReplacingOccurrencesOfString:@"," withString:@""];
    NSString *taxx =  newTax;
   NSString *tax =  taxx;//[[NSUserDefaults standardUserDefaults] objectForKey:@"tax"];
    if(tax.length==0)
        tax = @"";
    
    // create a mutable copy, and mutate it
    NSMutableString *mutTax = [tax mutableCopy];
    
    [[NSUserDefaults standardUserDefaults] setObject:mutTax forKey:@"tax"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    NSString* name = [self.nameTextField.text lastPathComponent];
    if ([name length]<=0) {
        [WBNewReceiptViewController showAlertWithTitle:nil message:NSLocalizedString(@"Please enter a name",nil)];
        return;
    }
    
    if (_receipt == nil) {
        
        NSString *imageFileName = nil;
        if (_image) {
            long long ms = ([[NSDate date] timeIntervalSince1970] * 1000LL);
            imageFileName = [NSString stringWithFormat:@"%lldx%d.jpg", ms, (int)[self.receiptsViewController receiptsCount]];
            NSString *path = [_trip fileInDirectoryPath:imageFileName];
            if(![WBFileManager forceWriteData:UIImageJPEGRepresentation(_image, 0.85) to:path]) {
                imageFileName = nil;
            }
        }
        
        
        // price:[NSDecimalNumber decimalNumberWithString:self.priceTextField.text]
        
        
        newReceipt =
        [[WBDB receipts] insertWithTrip:_trip
                                   name:name
                               category:[self.categoryButton titleForState:UIControlStateNormal]
                          imageFileName:imageFileName
                                 dateMs:_dateMs
                           timeZoneName:[_timeZone name]
                                comment:self.commentField.text
                                  price:[[NSDecimalNumber alloc] initWithString:price]
         //                                  price:[[NSDecimalNumber alloc] initWithString:self.priceTextField.text]
                                    tax:[NSDecimalNumber decimalNumberWithString:tax]
         //                                    tax:[NSDecimalNumber decimalNumberWithString:self.taxTextField.text]
                           currencyCode:[self.currencyButton.titleLabel text]
                           isExpensable:self.expensableSwitch.on
                             isFullPage:self.fullPageImageSwitch.on
                         extraEditText1:nil
                         extraEditText2:nil
                         extraEditText3:nil];
        
        if(!newReceipt)
        {
            
            [WBNewReceiptViewController showAlertWithTitle:nil message:NSLocalizedString(@"Cannot add this receipt",nil)];
            return;
        }
        
        [self.delegate viewController:self newReceipt:newReceipt];
        
    } else {
        newReceipt =
        [[WBDB receipts] updateReceipt:_receipt
                                  trip:_trip
                                  name:name
                              category:[self.categoryButton.titleLabel text]
                                dateMs:_dateMs
                               comment:self.commentField.text
                                 price:[NSDecimalNumber decimalNumberWithString:price]
         //                                 price:[NSDecimalNumber decimalNumberWithString:self.priceTextField.text]
                                   tax:[NSDecimalNumber decimalNumberWithString:tax]
         //                                   tax:[NSDecimalNumber decimalNumberWithString:self.taxTextField.text]
                          currencyCode:[self.currencyButton.titleLabel text]
                          isExpensable:self.expensableSwitch.on
                            isFullPage:self.fullPageImageSwitch.on
                        extraEditText1:nil
                        extraEditText2:nil
                        extraEditText3:nil];
        
        if(!newReceipt){
            [WBNewReceiptViewController showAlertWithTitle:nil message:NSLocalizedString(@"Cannot save this receipt",nil)];
            return;
        }
        [self.delegate viewController:self updatedReceipt:newReceipt fromReceipt:_receipt];
    }
    
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)actionCancel:(id)sender
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

+ (void)showAlertWithTitle:(NSString*) title message:(NSString*) message
{
    [[[UIAlertView alloc]
      initWithTitle:title message:message delegate:nil cancelButtonTitle:NSLocalizedString(@"OK",nil) otherButtonTitles:nil] show];
}

@end
