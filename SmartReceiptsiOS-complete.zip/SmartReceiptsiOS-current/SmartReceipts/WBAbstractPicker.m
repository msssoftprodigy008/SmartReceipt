//
//  WBPopoverPicker.m
//  SmartReceipts
//
//  Created on 14/03/14.
//  Copyright (c) 2014 Will Baumann. All rights reserved.
//

#import "WBAbstractPicker.h"

@implementation WBAbstractPicker

-(id)initAsDatePicker:(BOOL) asDatePicker withController:(UIViewController*) vc
{
    return [super init];
}

-(void)setTitle:(NSString *)title{
}

-(void)showPickerFromView:(UIView*) view {
}

-(void)showPickerFromBarButtonItem:(UIBarButtonItem*) barButtonItem {
}

@end
