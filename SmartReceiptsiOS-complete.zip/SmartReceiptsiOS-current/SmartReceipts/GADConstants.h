//
//  GADConstants.h
//  SmartReceipts
//
//  Created by William Baumann on 9/28/14.
//  Copyright (c) 2014 Will Baumann. All rights reserved.
//

#import <Foundation/Foundation.h>

extern NSString * const AD_UNIT_ID;