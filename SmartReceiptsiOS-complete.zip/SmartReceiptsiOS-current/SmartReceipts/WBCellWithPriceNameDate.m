//
//  WBTripCell.m
//  SmartReceipts
//
//  Created on 30/03/14.
//  Copyright (c) 2014 Will Baumann. All rights reserved.
//

#import "WBCellWithPriceNameDate.h"

@implementation WBCellWithPriceNameDate

@end
