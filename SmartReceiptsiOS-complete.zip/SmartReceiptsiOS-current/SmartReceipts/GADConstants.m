//
//  GADConstants.m
//  SmartReceipts
//
//  Created by William Baumann on 9/28/14.
//  Copyright (c) 2014 Will Baumann. All rights reserved.
//


#import <Foundation/Foundation.h>


NSString * const AD_UNIT_ID = @"ca-app-pub-5974528738468170/2726313041";


//  The required features for the trial task i.e.

//- Enable users to select gallery photos in addition to taking photos when launching the camera(done)

//- Allow locale based prices (right now, you can only do the US style of "10.00" but not the EU style of "10,00")

//- Alter price strings in the underlying database to ensure they are all decimal separated (as  opposed to common separated)

//United States  — $1,234,567.89 USD
//• Canada           — $1,234,567.89 CAD
//• Great Britain   — £1.234.567,89 GBP
//• European        — €1.234.567,89 EUR