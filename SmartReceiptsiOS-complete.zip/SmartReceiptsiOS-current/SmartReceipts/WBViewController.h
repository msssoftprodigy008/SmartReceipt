//
//  WBViewController.h
//  SmartReceipts
//
//  Created on 17/03/14.
//  Copyright (c) 2014 Will Baumann. All rights reserved.
//

#import <UIKit/UIKit.h>

/*
 * Base UIViewController for this application.
 */

@interface WBViewController : UIViewController

@end
